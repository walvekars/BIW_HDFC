{
    "name": "Fixation Module 2",
    "version": "15.0.1",
    "summary": "Fixing module for date change request",
    "category": "Fixation",
    "author": "Suprit S",
    "depends": ['multiple_order_process', 'base'],
    "data": [
        "views/fixing_2.xml"
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}